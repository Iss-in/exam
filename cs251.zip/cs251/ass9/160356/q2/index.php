<html>
<body>
<?php
$name = $addr = $email = $mno = $acc = $pass = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$name=$_POST["name"];
	$addr=$_POST["addr"];
	$email=$_POST["email"];
	$mno=$_POST["mno"];
	$acc=$_POST["acc"];
	$pass=$_POST["pass"];	
echo $name, " ", $addr, " ",$email, " ",$mno, " ",$acc, " ",$pass;
}
?>



