read num
b= ((${num}+3))
echo $b
