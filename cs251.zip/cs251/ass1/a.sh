
echo -n "asdsad"
echo -e "asdad"
