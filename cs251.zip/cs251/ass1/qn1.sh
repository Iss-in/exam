#!/bin/bash

declare -a arr=("one" "two" "three" "four" "five" "six" "seven" "eight" "nine" "ten" "eleven" "twelve" "thirteen" "fourteen" "fifteen" "sixteen" "seventeen" "eighteen" "nineteen" "twenty" "twenty one" "twenty two" "twenty three" "twenty four" "twenty five" "twenty six" "twenty seven" "twenty eight" "twenty nine" "thirty" "thirty one" "thirty two" "thirty three" "thirty four" "thirty five" "thirty six" "thirty seven" "thirty eight" "thirty nine" "forty" "forty one" "forty two" "forty three" "forty four" "forty five" "forty six" "forty seven" "forty eight" "forty nine" "fifty" "fifty one" "fifty two" "fifty three" "fifty four" "fifty five" "fifty six" "fifty seven" "fifty eight" "fifty nine" "sixty" "sixty one" "sixty two" "sixty three" "sixty four" "sixty five" "sixty six" "sixty seven" "sixty eight" "sixty nine" "seventy" "seventy one" "seventy two" "seventy three" "seventy four" "seventy five" "seventy six" "seventy seven" "seventy eight" "seventy nine" "eighty"
"eighty one" "eighty two" "eighty three" "eighty four" "eighty five" "eighty six" "eighty seven" "eighty eight" "eighty nine" "ninety" "ninety one" "ninety two" "ninety three" "ninety four" "ninety five" "ninety six" "ninety seven" "ninety eight" "ninety nine")
declare -a brr=("nothing" "twenty" "thirty" "forty" "fifty" "sixty" "seventy" "eighty" "ninety" )
declare -a crr=("hundread" "thousand" "lakh" "c" "crore" )







read num2
len1=${#num2}


if ! [[ "$num2" =~ ^[0-9]+$ ]]; then
        echo "Sorry integers only"
exit
fi
new=$(echo $num2 | sed 's/^0*//')
len1=${#new}

if ((len1>7));then
num5=${num2:$len1-7:7}
num=$(echo $num5 | sed 's/^0*//')
num3=${num2:0:len-7}
len=${#num}
len2=${#num3}




if(($len2==1));then
echo -n ${arr[$num3-1]} 
fi

if(($len2==2)) ;then
echo -n ${arr[${num3:0:2}-1]}  
fi


if(($len2==3));then
echo -n ${arr[${num3:0:1}-1]} "hundread "
if((${num3:1:2}!=0));then
echo -n  ${arr[${num3:1:2}-1]}
fi
fi




if(($len2==4)) ;then
echo -n ${arr[${num3:0:1}-1]} "thousand "
if((${num3:1:1}!=0));then 
echo -n ${arr[${num3:1:1}-1]} "hundread "
fi
if((${num3:2:2}!=0));then
 echo -n ${arr[${num3:2:2}-1]}
fi
fi
echo -n " crore "

fi
















if ((len1<=7));then
len=${len1}
num=${new}
fi

if(($len==1));then
echo ${arr[$num-1]}
fi


if(($len==2)) ;then
echo ${arr[${num:0:2}-1]}
fi


if(($len==3));then
echo -n ${arr[${num:0:1}-1]} "hundread "
if((${num:1:2}!=0));then
echo   ${arr[${num:1:2}-1]}
fi
fi




if(($len==4)) ;then
echo -n ${arr[${num:0:1}-1]} "thousand "
if((${num:1:1}!=0));then 
echo -n ${arr[${num:1:1}-1]} "hundread "
fi
if((${num:2:2}!=0));then
 echo ${arr[${num:2:2}-1]}
fi
fi



if (($len==5)); then
echo -n ${arr[${num:0:2}-1]} "thousand "
if((${num:2:1}!=0));then
echo -n ${arr[${num:2:1}-1]} "hundread " 
fi
if((${num:3:2}!=0));then
echo ${arr[${num:3:2}-1]}
fi
fi

if (($len==6)); then
echo -n ${arr[${num:0:1}-1]} "lakh " 
if((${num:1:2}!=0));then
echo -n ${arr[${num:1:2}-1]} "thousand " 
fi
if((${num:3:1}!=0));then
echo -n ${arr[${num:3:1}-1]} "hundread " 
fi
if((${num:4:2}!=0));then
echo  ${arr[${num:4:2}-1]}
fi
fi

if (($len==7)); then
echo -n ${arr[${num:0:2}-1]} "lakh " 
if((${num:2:2}!=0));then
echo -n ${arr[${num:2:2}-1]} "thousand " 
fi
if((${num:4:1}!=0));then
echo -n ${arr[${num:4:1}-1]} "hundread "
fi
if((${num:5:2}!=0));then
echo  ${arr[${num:5:2}-1]}
fi
fi
