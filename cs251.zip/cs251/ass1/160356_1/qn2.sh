num1=0
num2=0 
sum1=0
sum2=0
read path

files()
{
path=$1
l=$2
txt=$(cat $path)
l2=${#txt}
dot=0 
num=0
corr=0
re='^[0-9]+$'
 for ((i=0;i<l2;i++)) do
   ch=${txt:$i:1}
   ch2=${txt:$i-1:1}
   ch3=${txt:$i+1:1}
 
    if [[ "$ch" = "." || "$ch" = "?" || "$ch" = "!"  ]]; then
    ((dot++))
    fi
done

for ((i=0;i<l2;i++)) do
   ch=${txt:$i:1}
   ch2=${txt:$i-1:1}
   ch3=${txt:$i+1:1}
 
    if [[ "$ch" = *[0-9]*  ]]; then
       while [[ "$ch" = *[0-9]*  ]]
        do
        ((i++))
        ch=${txt:$i+1:1}
        done
      ((num++))
    fi

done



for ((i=0;i<l2;i++)) do
   ch=${txt:$i:1}
   ch2=${txt:$i-1:1}
   ch3=${txt:$i+1:1}
 
    if [[ "$ch" = "." && "$ch2" = *[0-9]*  && "$ch3" = *[0-9]*  ]]; then
             ((corr++))
fi
done

tem=$(( 2*$corr))
echo "   (F)"${f##*/}"-"$(expr $dot - $corr)"-"$(expr $num - $tem)
sum1=$(( sum1 + $dot ))
sum1=$(( sum1 - $corr ))
sum2=$(( $sum2 +  $num ))
sum2=$(( $sum2 - $tem ))

}






















files2()
{
path=$1
l=$2
txt=$(cat $path)
l2=${#txt}
dot=0 
num=0
corr=0
re='^[0-9]+$'
 for ((i=0;i<l2;i++)) do
   ch=${txt:$i:1}
   ch2=${txt:$i-1:1}
   ch3=${txt:$i+1:1}
 
    if [[ "$ch" = "." || "$ch" = "?" || "$ch" = "!"  ]]; then
    ((dot++))
    fi
done

for ((i=0;i<l2;i++)) do
   ch=${txt:$i:1}
   ch2=${txt:$i-1:1}
   ch3=${txt:$i+1:1}
 
    if [[ "$ch" = *[0-9]*  ]]; then
       while [[ "$ch" = *[0-9]*  ]]
        do
        ((i++))
        ch=${txt:$i+1:1}
        done
      ((num++))
    fi

done



for ((i=0;i<l2;i++)) do
   ch=${txt:$i:1}
   ch2=${txt:$i-1:1}
   ch3=${txt:$i+1:1}
 
    if [[ "$ch" = "." && "$ch2" = *[0-9]*  && "$ch3" = *[0-9]*  ]]; then
             ((corr++))
fi
done

tem=$(( 2*$corr))
num1=$(( $dot - $corr ))
num2=$(( $num - $tem ))
}

numx=0
numy=0

folders2()
{

path=$1
for f in "$path"/*; do
	l2=${#f}

	if [ -d "${f}" ]; then
        folders2 "$f"
                                                                                                                                    
       # echo "(D) " "folder ""-" $num1"-"$num2 
        elif [ -f "${f}" ]; then 
        files2 "$f" "$l2"
numx=$(expr $numx + $num1 )
numy=$(expr $numy + $num2 )
num1=0
num2=0

        fi
        
done

}






folders()
{

path=$1
for f in "$path"/*; do
	l2=${#f}
	if [ -d "${f}" ]; then
t=$f
        folders2 "$t"
echo -n "(D)"
echo -n "${t##*/}"
echo "-"$numx"-"$numy
echo -n "   "
numx=0
numy=0
        folders "$t"

                                                                                                   
        elif [ -f "${f}" ]; then 
        files "$f" "$l2"
        fi
        
done
 
}


folders "$path"
echo "exercize 1-B-"$sum1"-"$sum2
