<html>
<body>
<?php
$name = $addr = $email = $mno = $acc = $pass = "";
$db = new SQLite3('sq.db');
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$name=$_POST["name"];
	$addr=$_POST["addr"];
	$email=$_POST["email"];
	$mno=$_POST["mno"];
	$acc=$_POST["acc"];
	$pass=$_POST["pass"];	
	$qstr = "insert into records values ('$name', '$addr', '$email', '$mno', '$acc', '$pass')";
	$insres = $db->query($qstr);
echo $name, " ", $addr, " ",$email, " ",$mno, " ",$acc, " ",$pass;
}
?>


</body>
</html>
