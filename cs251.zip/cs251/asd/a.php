<?php
   var a = "sss";
   $data = new SQLite3('a.db');
   $tem = 'CREATE (
		fname TEXT,
		lname TEXT
		');
$data->queryExec($tem);
?> 
