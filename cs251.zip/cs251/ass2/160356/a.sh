read path
a=0
b=0
c=0
d=0
folders()
{

path=$1
for f in "$path"/*; do
	l2=${#f}
	if [ -d "${f}" ]; then
        t=$f
        folders "$t"
        
                                                                                                   
        elif [ -f "${f}" ]; then 
       filename=$(basename "${f}")
       extension="${filename##*.}"
       filename="${filename%.*}"

       if [ $extension == c ] ; then
    rm -r g.c
    awk '!NF{$0=">"}1' ${f} >> g.c
     
       b=$(awk -f q1.awk g.c | head -1)
       a=$(( $a+$b ))
       c=$(awk -f q1.awk g.c | head -2 | tail -1)
       d=$(( $d+$c )) 
        fi
        fi
done
 
}


folders "$path"
echo ${a} "lines of comment"
echo ${d} "quoted strings"
