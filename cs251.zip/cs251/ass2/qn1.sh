read path
files()
{
path=$1
l=$2
txt=$(cat $path)
l2=${#txt}
re='^[0-9]+$'
echo "${f##*/}"
}
folders()
{

path=$1
for f in "$path"/*; do
	l2=${#f}
	if [ -d "${f}" ]; then
        t=$f
        folders "$t"

                                                                                                   
        elif [ -f "${f}" ]; then 
        files "$f" "$l2"
        fi
        
done
 
}


folders "$path"

