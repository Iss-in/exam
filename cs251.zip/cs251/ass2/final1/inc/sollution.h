// This is a single line comment
/* This is a multi-line comment */
/* This is another
multi-line “comment”
considered as 4 lines
*/
#include <solution.h>
int solution(void)
{
char *s = "try combinations of/*      */ strings and /*comments*/ too";
return 0;
}
