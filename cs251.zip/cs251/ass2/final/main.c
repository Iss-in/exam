#include <stdio.h>
int main(void)
{
// The following output is the actual solution !!!
printf("7 lines of comments\n");
printf("3 quoted strings\n");
return 0;
}
