solution.c
// This is a single line comment
// This is a mu""""""""lti-line comment */
// This is another*/
/*dafasd*/
6454
5445
/*
asdasd
asdasd
kujkhkj

*/
#include <solution.h>
int so"lution(voi"d)
{
char *s = "try combination////s of strings and /*comments*/ too";
return 0;
}
