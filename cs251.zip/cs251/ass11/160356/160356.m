#step1
x=dlmread('train.csv',',',1,0);
X_train=x(: ,1);
y_train=x(: ,2);
X_train=[ones(rows(X_train),1),X_train];
%rows(X_train)
%columns(X_train)
#step2
w=rand(2,1);
#step3
figure(1);
scatter(X_train(: ,2),y_train,"marker",".");
hold on;
x1=transpose(X_train);
t=transpose(w)*x1; 
plot(transpose(X_train(: ,2)),t,"r","marker","+");
hold off;
#step4
figure(2);
w_direct=inv(transpose(X_train)*X_train) * transpose(X_train) * y_train;
scatter(X_train(: ,2),y_train,"marker",".");
hold on;
plot(transpose(X_train(: ,2)),transpose(w_direct)*x1,"r");
hold off;
#step5
figure(3);
scatter(transpose(X_train(: ,2)),y_train,"marker",".");
hold on;
nepoch=10;
n_train=10000;
count=0;
x(5,2);
for i = 1:nepoch
    for j = 1:n_train
     x2=transpose([1,x(j,1)]);
	z=(w(1,1) + w(2,1)*x(j,1) - x(j,2))*.00000001;
	w(1,1)=w(1,1)-z;
	w(2,1)=w(2,1)-z*x(j,1);
     w=w-.00000001 * (transpose(w) * x2 - y_train(j)) * x2;
          if mod(j,100)==0
              count=count+1;
              plot(X_train(: ,2),transpose(w)*x1);
          endif
    endfor
endfor   

hold off
   count;
#step 6
figure(4);
scatter(X_train(: ,2),y_train);
hold on;
plot(X_train(: ,2),transpose(transpose(w)*x1),"r");   
#step 7
w_direct;

xn=dlmread('test.csv',',',1,0);
X_test=xn(: ,1);
y_test=xn(: ,2);
X_test=[ones(rows(X_test),1),X_test];
%for i = 1:10500
%  
%  y_pred1(i)=w(1,1) + w(2,1)*xn(i,1);
%  endfor
y_pred1=X_test*w;
y_pred2=X_test*w_direct;
rows(y_test);
sum1=0;
sum2=0;

sqrt(mean((y_pred1 - y_test).^2))
sqrt(mean((y_pred2 - y_test).^2))
