import sys
num = raw_input("enter fractional number- ")
#base = input("enter base- ")
base = raw_input("enter the base ")
dot=0
l=0
ind=0
sign=0

for i in range(len(num)):
   if num[i]=='-':
      i=i+1

   if num[i] == '.':
      dot=dot + 1
      ind=i

   elif num[i].isdigit()==True:
        l=l + 1
        if int(num[i])>= int(base):
              print "wrong input"
              sys.exit()

   elif num[i].isalpha()==True:
        if num[i].isupper()==True:
           l=l+1
           if ord(num[i])-55 >= int(base): 
              print "wrong input"
              sys.exit()
        else:
            print "wrong input"
            sys.exit()
             
   else:
        print "wrong input"
        sys.exit()
if dot > 1:
  print "wrong input"
  sys.exit()

if dot > 0 :
   n=ind
else:
   n=l
j=0
dec=0


for i in range(len(num)):
   if num[i]=='-':
      i=i+1
   if num[i]=='.':
      n=n+1
   if num[i].isdigit()==True:
       t1=n-i-1
       temp = int(base) ** t1
       dec = dec + int(num[i]) * temp
   if num[i].isalpha()==True:
       t1=n-i-1
       temp = int(base) ** t1
       dec = dec + int(ord(num[i])-55) * temp     
if num[0]=='-':
 print "-",dec 
else:
 print dec
