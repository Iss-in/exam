import matplotlib.pyplot as plt
import numpy as np
fil = open("train.csv","r") 
n1=0
st=""
X_train=[[]]
Y_train=[[]]
x=fil.readline()
for line in fil:
     n1 = n1 + 1
     a=line[:-1].split(',')

     X_train[0].append(float(a[0]))
     Y_train[0].append(float(a[1]))
fil.close

X_train.insert(0,[])
for i in range(n1):
 X_train[0].append(1)

X=X_train
Y=Y_train


# STEP1
w=np.random.rand(2,1)
w=w.astype(float)
w1= np.transpose(w)
w2=np.matmul(w1,X_train)
#step 2
#for i in range(n1):
plt.plot([float(X_train[1][i]) for i in range(n1)] ,  [float(Y_train[0][i]) for i in range(n1)] , 'r+')
plt.plot([float(w2[0][i]) for i in range(n1)] ,  [float(Y_train[0][i]) for i in range(n1)] )

#plt.plot([i for i in range(n1)],[i*i for i in range(n1)])
plt.show()
plt.close()

#step 4

t1 = np.matmul(X,np.transpose(X))
t2= np.matrix(t1)
t3=t2.I
t4=np.matmul(X,np.transpose(Y))
t5=np.matmul(t3,t4)  #wdirecr
t6=np.transpose(t5)
t8=np.asarray(t6).reshape(-1)
t7=np.matmul(t8,X)

plt.plot([float(X_train[1][i]) for i in range(n1)] ,  [float(Y_train[0][i]) for i in range(n1)] , 'r+')
plt.plot([float(X[1][i]) for i in range(n1)] ,  [float(t7[i]) for i in range(n1)])
plt.show()
plt.close()
X1=np.matrix(X)
W=np.matrix(w)
wt=np.transpose(W)
wt=w.T
x_train=np.transpose(X)
y_train=np.transpose(Y)

#print x_train
#print y_train[8][0]

t=[0,0]
eta=.00000001

N=10
plt.plot([float(X_train[1][i]) for i in range(n1)] ,  [float(Y_train[0][i]) for i in range(n1)] , 'r+')
#for j in range(1, n1-1):
 # print x_train[j-1][1]


for nepoch in range(1, N):
	for j in range(1, n1):
		t3=(wt[0][0] + wt[0][1]*x_train[j-1][1])-y_train[j-1][0]
		w[0][0]=w[0][0]-eta*t3*1
		w[1][0]=w[1][0]-eta*t3*x_train[j-1][1]
		#if j%100 == 0:
			#plt.plot([float(X_train[1][i]) for i in range(n1)] ,  [float(Y_train[0][i]) for i in range(n1)] , 'r+')
			#wt=w.T
			#wtx1=[[]]
			#for i in range(1, n1+1):
				#wtx1[0].append(float(wt[0][0] + wt[0][1]*x_train[i-1][1]))
			#print wtx1
			#plt.plot(X[1],wtx1[0],'g')
plt.show()
plt.close()

plt.plot([float(X_train[1][i]) for i in range(n1)] ,  [float(Y_train[0][i]) for i in range(n1)] , 'r+')

ss=np.matmul(np.transpose(w),X)
plt.plot(X[1],ss[0])

plt.show()
plt.close()






print t5






n1=0


fil = open("test.csv","r") 
X_test=[[]]
Y_test=[[]]
x=fil.readline()
for line in fil:
     n1 = n1 + 1
     a=line[:-1].split(',')

     X_test[0].append(float(a[0]))
     Y_test[0].append(float(a[1]))
fil.close

X_test.insert(0,[])
for i in range(n1):
 X_test[0].append(1)	
#print X_test	;
y_pred1=[]
y_pred2=[]

sum1=0
sum2=0

for i in range(n1):
   y_pred1.append(w[0][0]+w[1][0]*X_test[1][i-1])
   sum1=sum1+(y_pred1[i-1]-Y_test[0][i-1])**2
sum1=((sum1)**.5)/n1
#print w[0][0]
#print w[1][0]

print sum1
for i in range(n1):
   y_pred2.append(t5[0][0]+t5[1][0]*X_test[1][i-1])
   sum2=sum2+(y_pred2[i-1]-Y_test[0][i-1])**2
sum2=(float(sum2)**.5)/n1
print sum2	
print X_test[0][0]
print y_pred2[0]
