import matplotlib.pyplot as plt
import numpy as np
a=1225
print a**.5
