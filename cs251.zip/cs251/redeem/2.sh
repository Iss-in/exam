d=`pwd`
cat $d b.xml
