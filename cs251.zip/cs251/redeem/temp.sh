IFS=''
tr '/' '|'  < a.xml > b.xml
space1=0
d=`pwd`
echo $d
work ()
{
space1=$1
space2=0
if [ "$space1" -gt "$space2" ]
then
 cd ..
 work $space2
fi

cat "$d/b.xml" | while read line
do
   #echo $line
   foo=$line
    for (( i=0; i<${#foo}; i++ )); do
      if [ ${foo:$i:1} == " " ]
      then
          space2=$((space2 + 1))
      else
          if [ ${foo:$i:5} == "<dir>" ]      # to check folder
          then
               read lin
               #echo  $lin
               boo=$lin
               echo  $lin > di.txt
               sed -e 's/<name>\(.*\)<|name>/\1/' di.txt > temp1.txt
               a=`cat temp1.txt`
               mkdir $a
               rm -f di.txt temp1.txt 
               cd $a
               work $space2	
          fi
          #done
          #######################################################
          if [ ${foo:$i:6} == "<file>" ]
          then 
          read lin 
          echo $lin > name.txt
          read lin
          echo $lin > size.txt
          sed -e 's/<name>\(.*\)<|name>/\1/' name.txt > name1.txt
          sed -e 's/<size>\(.*\)<|size>/\1/' size.txt > size1.txt
          n=`cat name1.txt`
          s=`cat size1.txt | xargs`
          fallocate -l ${s}k $n
          rm -f name.txt name1.txt size.txt size1.txt
          fi

      fi        
    done
 
 echo $space2
 space1=space2
 space2=0
done
}
work $space1
