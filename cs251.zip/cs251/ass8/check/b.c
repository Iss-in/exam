#include<stdio.h>
int b()
{
int c;scanf("%denter nmb",&c);
printf("2nd");
return 0;
}
