

temp=open("out.txt",'r')
a1=open("1_1.txt",'w')
b1=open("1_2.txt",'w')
c1=open("1_3.txt",'w')
d1=open("1_4.txt",'w')
e1=open("1_5.txt",'w')
for line in temp.readlines():
	val=line.split()
	if(val[1]=="1"):
		a1.write(val[0]+" "+val[2]+"\n")
	if(val[1]=="2"):
		b1.write(val[0]+" "+val[2]+"\n")
	if(val[1]=="4"):
		c1.write(val[0]+" "+val[2]+"\n")
	if(val[1]=="8"):
		d1.write(val[0]+" "+val[2]+"\n")
	if(val[1]=="16"):
		e1.write(val[0]+" "+val[2]+"\n")
temp.close()
a1.close()
b1.close()
c1.close()
d1.close()
e1.close()
###############################
a1=0 

table= []
tablex= []
init=open("out.txt",'r')
inn=0
inn2=0
for line in init.readlines():
	val=line.split()
	inn+=1
	if(inn==500):
		inn=0
		table.append([])
		table[inn2].append(float(val[0]))
		tablex.append([])
		tablex[inn2].append(float(val[0]))
		inn2+=1
init.close()
temp.close()

temp=open("out.txt",'r')
a=open("thread_1",'w')
b=open("thread_2",'w')
c=open("thread_4",'w')
d=open("thread_8",'w')
e=open("thread_16",'w')
i=0
tem=0
flag=0
ele=""
count=1
xyz=0
for line in temp.readlines():
	val=line.split()
	if(count==100):
		#print("yes")
		tem/=100
		t=t+" "
		e.write(t)
		e.write(str(tem))
		e.write("\n")
		table[a1].append(tem)
		tablex[a1].append(tem)
		a1+=1
		tem=0
		ele="-1"
		count=1
	if(int(val[1])==1):
		tem+=float(val[2])
		ele=val[1]
		t=val[0]
	elif(ele=="1"):
		tem/=100
		t=t+" "
		a.write(t)
		a.write(str(tem))
		a.write("\n")
		table[a1].append(tem)
		tablex[a1].append(tem)
		tem=0
		ele="-1"
	elif(int(val[1])==2):
		tem+=float(val[2])
		ele=val[1]
		t=val[0]
	elif(ele=="2"):
		tem/=100
		t=t+" "
		b.write(t)
		b.write(str(tem))
		b.write("\n")
		table[a1].append(tem)
		tablex[a1].append(tem)
		tem=0
		ele="-1"
	elif(int(val[1])==4):
		tem+=float(val[2])
		ele=val[1]
		t=val[0]
	elif(ele=="4"):
		tem/=100
		t=t+" "
		c.write(t)
		c.write(str(tem))
		c.write("\n")
		table[a1].append(tem)
		tablex[a1].append(tem)
		tem=0
		ele="-1"
	elif(int(val[1])==8):
		tem+=float(val[2])
		ele=val[1]
		t=val[0]
	elif(ele=="8"):
		tem/=100
		t=t+" "
		d.write(t)
		d.write(str(tem))
		d.write("\n")
		table[a1].append(tem)
		tablex[a1].append(tem)
		tem=0
		ele="-1"
	elif(int(val[1])==16):
		#	print("yes")
		count+=1
		tem+=float(val[2])
		ele=val[1]
		t=val[0]

if(count==100):
		#print("yes")
		tem/=100
		t=t+" "
		e.write(t)
		e.write(str(tem))
		e.write("\n")
		table[a1].append(tem)
		tablex[a1].append(tem)
		tem=0
		ele="-1"
		count=1		
temp.close()
a.close()
b.close()
c.close()
d.close()
e.close()
#########################################################
i=0
j=2

while(i<inn2):
	while(j<6):
		table[i][j]=float(table[i][1])/float(table[i][j])
		j+=1
	i+=1
	j=2
	#print("\n")

i=0
while(i<inn2):
	table[i][1]=1
	i+=1
'''
for i in range(4):
	for j in range(6):
		print(table[i][j]," ", end='')
	print("\n")
for i in range(4):
	for j in range(6):
		print(tablex[i][j]," ", end='')
	print("\n")'''

###########################################################


tp=open("out.txt",'r')
i=0
tem=0
flag=0
ele=""
count=1
xyz=0
xy=0
cnt=0
for line in tp.readlines():
	val=line.split()
	if(count==100):
		#print("yes")
		table[xy].append(xyz/100)
		xyz=0
		xy+=1
		count=1
		ele="-1"
	if(int(val[1])==1):
		#print("yes")
		ele=val[1]
		tem=float(val[2])
		xyz+=(tablex[xy][1]/tem - table[xy][1])**2
	elif(ele=="1"):
		#print(cnt)
		table[xy].append(xyz/100)
		xyz=0
		ele="-1"
	elif(int(val[1])==2):
		ele=val[1]
		tem=float(val[2])
		xyz+=(tablex[xy][2] / tem - table[xy][2])**2
	elif(ele=="2"):
		ele="-1"
		table[xy].append(xyz/100)
		xyz=0
	elif(int(val[1])==4):
		ele=val[1]
		tem=float(val[2])
		xyz+=(tablex[xy][3]/tem - table[xy][3])**2
	elif(ele=="4"):
		ele="-1"
		table[xy].append(xyz/100)
		xyz=0
	elif(int(val[1])==8):
		ele=val[1]
		tem=float(val[2])
		xyz+=(tablex[xy][4]/tem - table[xy][4])**2
	elif(ele=="8"):
		ele="-1"
		table[xy].append(xyz/100)
		xyz=0
	elif(int(val[1])==16):
		ele=val[1]
		count+=1
		#print(xy)
		tem=float(val[2])
		xyz+=(tablex[xy][5]/tem - table[xy][5])**2

if(count==100):
		#print("yes")
		table[xy].append(xyz/100)
		xyz=0
		xy+=1
		count=1
		ele="-1"
temp.close()
'''
for i in range(4):
	table[i].append(4)'''
out=open("variance.txt",'w')
for i in range(inn2):
	for j in range(11):
		out.write(str(table[i][j])+" ")
	out.write("\n")



'''for i in range(4):
	for j in range(11):
		print(table[i][j]," ", end='')
	print("\n")'''
