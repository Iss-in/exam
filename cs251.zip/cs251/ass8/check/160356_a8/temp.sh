#tr -d "\n\r" < params.txt >> params.txt
#tr -d "\n\r" < threads.txt >> threads.txt
#tr -d "\n\r" < params.txt
read -r param < params.txt
read -r thr < threads.txt
#param=$param | tr "\n" " "
a=( $param[@] )
b=( $thr[@] )
len1=${#a[@]}
len2=${#b[@]}
a[$(($len1 - 1))]=$(echo ${a[$(($len1 - 1))]}| cut -d'[' -f 1)
b[$(($len2 - 1))]=$(echo ${b[$(($len2 - 1))]}| cut -d'[' -f 1)
#cat echo $len1 " " $len2
for (( i=0; i<$len1; i++))
do
   for (( j=0; j<$len2; j++))
   do 
	for (( k=0; k<100; k++))
        do 
    	   echo -n ${a[i]} " ">> out.txt
     	   echo -n ${b[j]} " ">> out.txt 
    	   ./b.out ${a[i]} ${b[j]} >> out.txt
     	   echo  >> out.txt
        done
   done
done	
