#include<stdio.h>
void b();
int main()
{
int c;scanf("%denter nmb",&c);
printf("ist");
b();
return 0;
} 
