#include "temp.h"
int  m()
{
  printf("another\n");
 return 0;
}

int f()
{
printf("check header\n");	
return 0;
}


