#include "temp.h"
int m(void)
{
  printf("2\n");
  return 0;
}
