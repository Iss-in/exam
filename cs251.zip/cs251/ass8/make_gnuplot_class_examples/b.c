#include "temp.h"

int main(void)
{
  printf("1\n");
  f();
  m();
  return 0;
}

