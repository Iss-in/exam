my <- array(1:12, dim=c(1,4))
my2 <- array(3:7, dim=c(1,4))
my
my2
my3=my*my2
my3
