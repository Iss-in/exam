pdf <- function(data,j,k)
{
pdata <- rep(0, 100);
for(i in j:k){
    val=round(data[i], 0);
    if(val <= 100){
       pdata[val] = pdata[val] + 1/ 100; 
    }
}
return(pdata)
}






y=rexp(n=50000,.2)
yz=sort(y,decreasing = FALSE)
x <-c(1)
ind=1
while(ind!=50001){
x[ind]=ind
ind=ind+1
}


plot(x,yz,pch=19,col='red',cex=.1,xlab="X",ylab='Y',main='Exponential distribution')
legend("topright", inset=.1, title="Exponential distribution",c(""),horiz=TRUE)	

pdata1 <- pdf(y,1,100)
pdata2 <- pdf(y,101,200)
pdata3 <- pdf(y,201,300)
pdata4 <- pdf(y,301,400)
pdata5 <- pdf(y,401,500)

cdata1 <- rep(0, 100)
cdata2 <- rep(0, 100)
cdata3 <- rep(0, 100)
cdata4 <- rep(0, 100)
cdata5 <- rep(0, 100)

cdata1[1] <- pdata1[1]
cdata2[1] <- pdata2[1]
cdata3[1] <- pdata3[1]
cdata4[1] <- pdata4[1]
cdata5[1] <- pdata5[1]

for(i in 2:100){
	cdata1[i] = cdata1[i-1] + pdata1[i]
	cdata2[i] = cdata2[i-1] + pdata2[i]
	cdata3[i] = cdata3[i-1] + pdata3[i]
	cdata4[i] = cdata4[i-1] + pdata4[i]
	cdata5[i] = cdata5[i-1] + pdata5[i]
}



x1=x[1:100]
x2=x[101:200]
x3=x[201:300]
x4=x[301:400]
x5=x[401:500]



attach(mtcars)


m1=mean(y[1:100])
v1=var(y[1:100])
par(mfrow=c(2,1))
plot(x1,pdata1,pch=19,"l",col='red',cex=.1,xlab="X",ylab='Y',main='pdf of ist ')
plot(x1,cdata1,pch=19,"o",col='green',cex=.1,xlab="X",ylab='Y',main='cdf of ist ')

print(paste0("ist mean is  ", m1," ,ist vairance is ",v1 ))


m2=mean(y[101:200])
v2=var(y[101:200])
par(mfrow=c(2,1))
plot(x2,pdata2,pch=19,"l",col='red',cex=.1,xlab="X",ylab='Y',main='pdf of 2nd ')
plot(x2,cdata2,pch=19,"o",col='green',cex=.1,xlab="X",ylab='Y',main='cdf of 2nd ')
print(paste0("2nd mean is  ", m2," ,2nd vairance is ",v2 ))

m3=mean(y[201:300])
v3=var(y[201:300])
par(mfrow=c(2,1))
plot(x3,pdata3,pch=19,"l",col='red',cex=.1,xlab="X",ylab='Y',main='pdf of 3RD ')
plot(x3,cdata3,pch=19,"o",col='green',cex=.1,xlab="X",ylab='Y',main='cdf of 3rd ')
print(paste0("3rd mean is  ", m3," ,3rd vairance is ",v3 ))

m4=mean(y[301:400])
v4=var(y[301:400])
par(mfrow=c(2,1))
plot(x4,pdata4,pch=19,"l",col='red',cex=.1,xlab="X",ylab='Y',main='pdf of 4th ')
plot(x4,cdata4,pch=19,"o",col='green',cex=.1,xlab="X",ylab='Y',main='cdf of 4th ')
print(paste0("4th mean is  ", m4," ,4th vairance is ",v4 ))

m5=mean(y[401:500])
v5=var(y[401:500])
par(mfrow=c(2,1))
plot(x5,pdata5,pch=19,"l",col='red',cex=.1,xlab="X",ylab='Y',main='pdf of 5th ')
print(paste0("5th mean is  ", m5," ,5th vairance is ",v5 ))
plot(x5,cdata5,pch=19,"o",col='green',cex=.1,xlab="X",ylab='Y',main='cdf of 5th  ')

Mean=rep(0,500)
count=1
l=1
m=100
while(count!=501){
Mean[count]=mean(y[l:m])
l=l+100
m=m+100
count=count+1
}


pdatam <- pdf(Mean,1,100)	
cdatam <- rep(0, 100)

cdatam[1] <- pdatam[1]

for(i in 2:100){
	cdatam[i] = cdatam[i-1] + pdatam[i]
}

par(mfrow=c(3,1))
plot(x1,pdatam,pch=19,"l",col='blue',cex=.2,xlab="X",ylab='PDF',main='pdf of MEANS ')
plot(x1,cdatam,pch=19,"o",col='blue',cex=.2,xlab="X",ylab='CDF',main='cdf of MEANS ')
tab <- table(round(Mean))

str(tab)
plot(tab, "h", xlab="Value", ylab="Frequency")



MMean=mean(Mean)
Sd=sd(Mean)
print(paste0("MEAN of means is  ", MMean," ,SD of standerd deviations is ",Sd ))
diff=round(MMean-5)
if(diff==0){
	print("mean is close to expected value")
}
else
{
print("mean is not close to expected value")
}


if(diff==0){
	print("mean is close to expected value")
}
else
{
print("mean is not close to expected value")
}
