#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{
FILE *fp = fopen("acc.txt","r");
 
    char ist[10];char sec[10];
 
        while( fscanf(fp, "%s", ist) != EOF )
        {
           fscanf(fp, "%s", sec);
           printf("%s ", ist);
           printf("%s\n", sec);
        }
return 0;
}
