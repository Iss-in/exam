#include<stdio.h>
#include<stdlib.h>
#include<sys/time.h>
#include<math.h>
#include<fcntl.h>
#include<pthread.h>

#define USAGE_EXIT(s) do{ \
                             printf("Usage: %s <# of elements>\n %s\n", argv[0], s); \
                            exit(-1);\
                    }while(0);

#define TDIFF(start, end) ((end.tv_sec - start.tv_sec) * 1000000UL + (end.tv_usec - start.tv_usec))

struct Trans{
                       int seq;
                       int type;
                       double amount;
                       int ac1;
                       int ac2;
};

  double list[10000][2];
  pthread_mutex_t lock;


void* work(void *arg)
{
struct Trans *temp1 = (struct Trans *) arg;

pthread_mutex_lock(&lock);
int ind=temp1->ac1 - 1001;
int ind2=temp1->ac2 - 1001;
double am=temp1->amount;
//printf("initial is %lf\n",list[ind].bal);
//printf("%d %d %lf %d %d\n",temp->seq,temp->type,temp->amount,temp->ac1,temp->ac2);
if(temp1->type==1)
       list[ind][1]+=.99*am;
else
if(temp1->type==2)
       list[ind][1]-=1.01*am;
else
if(temp1->type==3)
       list[ind][1]=1.071*list[ind][1];
else 
{ 
       list[ind][1]-=1.01*am;
       list[ind2][1]+=.99*am;
}
pthread_mutex_unlock(&lock);
//printf("%d %d %lf %d %d\n",temp1->seq,temp1->type,temp1->amount,temp1->ac1,temp1->ac2);
//printf("Type is %d  amount is %lf\n",temp1->type,am);
//printf("final is %lf\n\n",list[ind].bal);
}



int main(int argc, char **argv)
{


  struct timeval start, end;
  int *a, num_trans, ctr,num_threads;
  double max;
  if(argc !=5)
           USAGE_EXIT("not enough parameters");

  num_trans = atoi(argv[3]);
  if(num_trans <=0)
          USAGE_EXIT("invalid no of transcations");
  num_threads = atoi(argv[4]);
  if(num_threads <=0)
           USAGE_EXIT("invalid o of threads");


  pthread_t threads[num_threads];
  gettimeofday(&start, NULL);



  FILE *fq = fopen(argv[1],"r");
 char ch1[10],ch2[10];int i=0;

   while( fscanf(fq, "%s %s ", ch1,ch2) != EOF )
        {
         list[i][0]=atoi(ch1);
         list[i++][1]=atof(ch2); 
        }
  fclose(fq);
 /* for(int i=0;i<10000;i++)
  printf("%d  %lf \n",ind[i].ac,ind[i].bal);*/



  FILE *fp = fopen(argv[2],"r");
  struct Trans *trans;
  trans = malloc(num_trans*sizeof(struct Trans));
  char q[10],b[10],c[10],d[10],e[10];int j=0;
  while( fscanf(fp, "%s %s %s %s %s", q,b,c,d,e) != EOF )
        {
        trans[j].seq=atoi(q); trans[j].type=atoi(b); trans[j].amount=atof(c);trans[j].ac1=atoi(d);trans[j].ac2=atoi(e);
       j++;
        // printf("%d %d %lf %d %d\n",trans[j].seq,trans[j].type,trans[j].amount,trans[j].ac1,trans[j].ac2);
        }
fclose(fp); 
  
int tr=0;
for(int ctr=0; ctr < num_trans; ++ctr){
    if(tr>num_threads)
      tr=0;
    if(pthread_create(&threads[tr], NULL,work,trans+ctr) != 0){
              perror("pthread_create");
              exit(-1);
        }
    tr++;
     }
     
     for(int ctr=0; ctr <num_threads; ++ctr)
        pthread_join(threads[ctr], NULL);



	
 for(int i=0;i<10000;i++)
  printf("%d  %lf \n",(int)list[i][0],list[i][1]);
}
